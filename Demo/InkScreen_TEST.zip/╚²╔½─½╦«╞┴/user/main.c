#include "stm32f10x.h"
#include "Sys.h"

#include "LED.h"
#include "SPISoftware.h"
#include "InkScreen.h"
#include "InkScreen_Picture.h"


int main(void) {
	NVIC_Configuration();
	RCC_Configuration();
	
	LED_Init();
	SPI_Software_Init();
	InkScreen_Init();
	
	
	InkScreen_Wakeup();
	
  InkScreen_SelectLayer(InkScreen_BlackLayer);
//	InkScreen_DrawNum(0, 0, 343, 3, 16, BLACK);
//	InkScreen_DrawPicture(0,0,152,152, gImage_test, CANVAS_Coloured);
	
  InkScreen_SelectLayer(InkScreen_RedLayer);
//  EPD_ShowChinese(20,136,"֣���о�԰����",16,BLACK);
	
	InkScreen_DrawPicture(0,0,152,152, gImage_teacher1, CANVAS_Coloured);
	
  InkScreen_Display();
  InkScreen_DeepSleep();
	
	while(1) {
		LED_Flash(500);
	}
}
