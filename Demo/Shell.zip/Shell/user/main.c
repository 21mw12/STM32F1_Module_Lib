#include "stm32f10x.h"
#include "Sys.h"
#include "USART1.h"
#include "Shell.h"

int main(void) {
	NVIC_Configuration();
	RCC_Configuration();
	
	USART1_Init();
	
	Shell_Run();
	
	while(1) {
		
	}
}
